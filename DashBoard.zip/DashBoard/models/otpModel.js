const mongoose = require('mongoose');


var otpVerificationSchema = new mongoose.Schema({

    userId:{
        type : String
    },
    otp: {
        type: String
    },
    createdAt: {
        type: Date
    },
    expiresAt: {
        type: Date
    }

});

module.exports = mongoose.model('otpVerification', otpVerificationSchema);
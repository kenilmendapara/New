const mongoose = require('mongoose');


var serviceSchema = new mongoose.Schema({

    vehicleNumber: {
        type: String
    },
    email: {
        type: String
    },
    pickUpDate: {
        type: Date
    },
    dropDate: {
        type: Date
    },
    location: {
        type: String
    }

});

module.exports = mongoose.model('Service', serviceSchema);
const express = require('express');
const app = express();
const  {port} = require('./config/config')

const mongoose = require('mongoose');
mongoose.connect("mongodb://0.0.0.0:27017/Task-4", {
    useNewUrlParser: true
});

const route = require('./routes/route')
app.use('/', route);

app.listen(port, () => {
    console.log(`server is listening on http://localhost:${port}/login`);
});
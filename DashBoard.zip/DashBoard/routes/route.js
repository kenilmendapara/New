const express = require('express');
const ejs = require('ejs');
const path = require('path');
const bodyParser = require('body-parser');
const route = express();

const controller = require('../controllers/controller');

const static_path = path.join(__dirname, "../public/");
route.use(express.static(static_path));

route.use(bodyParser.json());
route.use(bodyParser.urlencoded({ extended: true }));

route.set('view engine', 'ejs');
route.set('views', './views');

route.get("/", controller.getHomePage);

route.get("/login", controller.getLoginPage);
route.post("/login", controller.postVerifyLogin);

route.get("/register", controller.getRegisterPage);

route.post('/register', controller.postInsertUser);

route.get("/dashboard", controller.getDashboard);

route.get("/error404", controller.getError404Page);

route.get("/error500", controller.getError500Page);

route.get("/list", controller.getShowList);

route.get("/add", controller.getAddNew);

route.get("/edit", controller.getEditPage);

route.get('/forget', controller.getForget);

route.post('/forget', controller.postForgetVerify);

route.get('/otpVerification', controller.getOtpVerification);

route.post('/otpVerification', controller.postOtpVerification);

route.get('/forget-password', controller.getForgetPassword);

module.exports = route;
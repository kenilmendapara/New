const User = require('../models/userModel');
const otpVerification = require('../models/otpModel');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const config = require('../config/config');
const nodemailer = require('nodemailer');


//<<<----- For Get Home Page----->>>
const getHomePage = async (req, res) => {
    try {

        res.render('dashboard', { title: "Dashboard" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get Login Page----->>>
const getLoginPage = async (req, res) => {
    try {

        res.render('login', { title: "Login" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get Register Page----->>>
const getRegisterPage = async (req, res) => {
    try {

        res.render('register', { title: "Registration" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Password Bcrypt ----->>>
const securePassword = async (password) => {
    try {

        const passwordHash = await bcrypt.hash(password, 10);
        return passwordHash;

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Insert User ----->>>
const postInsertUser = async (req, res) => {

    try {

        const spassword = await securePassword(req.body.password)

        const user = new User({
            username: req.body.username,
            email: req.body.email,
            mobileno: req.body.mobileno,
            address: req.body.address,
            password: spassword,
            usertype: req.body.usertype

        });

        const token = await user.generateAuthToken();

        const userData = await user.save();

        if (userData) {
            sendVerifyMail(req.body.username, req.body.email, userData._id);

            res.render('register', { title: 'Registration', message: 'Your Registration has been successfully, Please Verify email' });
        } else {
            res.render('register', { title: 'Registration', message: 'Your Registration has been failed..' });
        }

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Mail Varification ----->>>
const sendVerifyMail = async (username, email, _id) => {
    try {

        const transpoter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 587,
            secure: false,
            requireTLS: true,
            auth: {
                user: config.emailUser,
                pass: config.emailPassword
            }
        });


        const mailOptions = {

            from: config.emailUser,
            to: email,
            subject: 'For Varification E-mail',
            html: '<p>Hii ' + username + ', Please click here to <a href="http://localhost:2020/verify?id=' + _id + '"> verify </a> your mail.</p>'

        }
        transpoter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.log(error);
            } else {
                console.log("Email has been sent :- ", info.response);
            }

        });

    } catch (error) {

        console.log(error.message);

    }

};


//<<<----- For Verify Login User ----->>>
const postVerifyLogin = async (req, res) => {

    try {

        const email = req.body.email;
        const password = req.body.password;
        const userData = await User.findOne({ email: email });

        if (userData) {

            const passwordMatch = await bcrypt.compare(password, userData.password);
            const token = await userData.generateAuthToken();
            console.log(token);

            if (passwordMatch) {
                if (userData.is_verified === 0) {

                    res.render('login', { title: 'Login', message: 'Please Verify your Email..' });


                } else {

                    sendOtpVerificationMail();

                    if (userData.usertype === 'customer') {

                        //req.session._id = userData._id;
                        Service.find({ email: email }, (err, docs) => {
                            if (!err) {

                                res.render('customerHome', { title: 'Services', list: docs });
                            }
                            else {
                                console.log('Error in retrieving customers list :' + err);
                            }
                        });

                    } else {

                        //req.session._id = userData._id;
                        res.redirect('/otpVerification');

                    }
                }

            } else {
                res.render('login', { title: 'Login', message: 'Your Details Is Incorrect' });
            }

        }
        else {
            res.render('login', { title: 'Login', message: ' Your Details Is Incorrect' });
        }

    } catch (error) {

        console.log(error.message);

    }

};

//<<<----- For Get OTP Verfication Page----->>>
const getOtpVerification = async (req, res) => {
    try {

        res.render('otp', { title: "OTP Verification" })

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Get OTP Verfication ----->>>
const postOtpVerification = async (req, res) => {
    try {

        const otp = req.body.otp;

        if (!otp) {
            res.render("otp", { title: "OTP Verification", message: "Empty otp is not allowed" })
        }
        else {
            const otpVerificationRecord = await otpVerification.find({ otp: otp });
            if (!otpVerificationRecord) {

                res.render("otp", { title: "OTP Verification", message: "Please enter valid otp" })
            }
            else {

                const { expiresAt } = otpVerificationRecord[0];
                const otpHash = otpVerificationRecord[0].otp;

                if (expiresAt < Date.now()) {
                    await otpVerification.deleteMany({ _id });
                    res.render("otp", { title: "OTP Verification", message: "otp is expired. Please request again" })
                } else {
                    const validOtp = await bcrypt.compare(otp, optHash)

                    if (!validOtp) {

                        res.render("otp", { title: "OTP Verification", message: "Please enter valid otp" })
                    } else {

                        res.redirect("/dashboard");
                    }
                }


            }
        }

        //res.render('otp', { title: "OTP Verification" })

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For OTP Verification Send Email ----->>>
const sendOtpVerificationMail = async ({_id, email}) => {

    try {

        const otp = `${Math.floor(1000 + Math.random() * 9000)}`;

        const transpoter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 587,
            secure: false,
            requireTLS: true,
            auth: {
                user: config.emailUser,
                pass: config.emailPassword
            }
        });

        const mailOptions = {
            from: config.emailUser,
            to: email,
            subject: 'For Verify Otp',
            html: `<p> Your OTP is <b>${otp}</b>.</p>
                   <p> Please verify your email...<.p>
                   <p> Your otp is expires in 5 minutes.</p>`
        }

        // const otpHash = await bcrypt.hash(otp, 10);

        const newOtpVerification = await new otpVerification({
            userId : _id,
            otp: otp,
            createdAt: Date.now(),
            expiresAt: Date.now() + 300000,
        });

        await newOtpVerification.save();

        await transpoter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.log(error);
            } else {
                console.log("Email has been sent :- ", info.response);
            }

        });

    } catch (error) {

        console.log(error.message);

    }

};


//<<<----- For Display forget Page ----->>>
const getForget = async (req, res) => {

    try {

        res.render('forget', { title: 'Forget' });

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Forget Email Verify ----->>>
const postForgetVerify = async (req, res) => {

    try {

        const email = req.body.email;
        const userData = await User.findOne({ email: email });

        if (userData) {

            if (userData.is_verified === 0) {

                res.render('forget', { title: 'Forget', message: 'Please Verify your Email..' });

            } else {

                const token = userData.token
                sendResetPasswordMail(userData.username, userData.email, token);
                res.render('forget', { title: 'Forget', message: 'Please check your mail to reset password.' });
            }

        } else {
            res.render('forget', { title: 'Forget', message: "Your E-mail is Incorrect" });
        }


    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Reset Password Send Email ----->>>
const sendResetPasswordMail = async (username, email, token) => {
    try {

        const transpoter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 587,
            secure: false,
            requireTLS: true,
            auth: {
                user: config.emailUser,
                pass: config.emailPassword
            }
        });

        const mailOptions = {
            from: config.emailUser,
            to: email,
            subject: 'For Reset Password',
            html: '<p>Hii ' + username + ', Please click here to <a href="http://localhost:2020/forget-password?token=' + token + '"> Reset </a> your Password.</p>'
        }
        transpoter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.log(error);
            } else {
                console.log("Email has been sent :- ", info.response);
            }

        });

    } catch (error) {

        console.log(error.message);

    }

};


//<<<----- For New Password Set ----->>>
const getForgetPassword = async (req, res) => {

    try {

        const token = req.query.token;
        const tokenData = await User.findOne({ token: token });
        if (tokenData) {

            res.render('forget-password', { title: 'New Password', _id: tokenData._id });

        } else {

            res.render('404-error', { title: '404 Page Not Found', message: 'Your Token Is Invalid.' });

        }


    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Set Updated Password  ----->>>
const resetPassword = async (req, res) => {

    try {

        const password = req.body.password;
        const _id = req.body._id;

        const secure_password = await securePassword(password);

        const updatedData = await User.findByIdAndUpdate({ _id: _id }, { $set: { password: secure_password }, token: "" });

        if (updatedData) {

            res.redirect('/login');
        }


    } catch (error) {

        console.log(error.message);

    }
};




//<<<----- For Get 404 Page----->>>
const getError404Page = async (req, res) => {
    try {

        res.render('404-error', { title: "404 error" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get 500 Page----->>>
const getError500Page = async (req, res) => {
    try {

        res.render('500-error', { title: "500 server error" })

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Get Dashboard Page----->>>
const getDashboard = async (req, res) => {
    try {

        res.render('dashboard', { title: "Dashboard" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get List Page----->>>
const getShowList = async (req, res) => {
    try {

        res.render('list', { title: "List" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get Add New Page----->>>
const getAddNew = async (req, res) => {
    try {

        res.render('add', { title: "Add new" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get Edit Page----->>>
const getEditPage = async (req, res) => {
    try {

        res.render('edit', { title: "Edit" })

    } catch (error) {

        console.log(error.message);

    }
};



module.exports = {

    getHomePage,
    getLoginPage,
    getRegisterPage,
    getError404Page,
    getError500Page,
    getDashboard,
    getShowList,
    getAddNew,
    getEditPage,
    postInsertUser,
    postVerifyLogin,
    getOtpVerification,
    postOtpVerification,
    getForget,
    postForgetVerify,
    getForgetPassword

}
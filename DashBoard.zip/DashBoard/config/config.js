const sessionSecret = "mysitesessionsecret";
const emailUser = 'kenilpatel1552@gmail.com';
const emailPassword = 'ysobvfmfwmkguaos'; 
const myString = 'fdgdgfdifhfdivhfdvfdhfdvhfdv';
const port = process.env.PORT || 2020;

module.exports = {
    sessionSecret,
    emailUser,
    emailPassword,
    myString,
    port
}
const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema({
    customername: {
        type: String,
        // unique: true,
        // require: true,
        // trim : true,
        // minlength : [2, "username is has minimum 2 letter"],
        // maxlength : [20, "username is has maximum 20 letter"]
    },
    email: {
        type: String,
        // unique: true,
        // require: true,
        // trim : true,
        // validate(value){
        //     if(!validator.isEmail(value)){
        //         throw new Error("Email is Invalid.")
        //     }
        // }

    },
    mobileno: {
        type: Number,
        // unique: true,
        // require: true,
        // minlength : [10, "username is has minimum 10 letter"],
        // maxlength : [12, "username is has maximum 12 letter"]
    },
    birthDate: {
        type: Date,
        // require: true
    },
    address: {
        type: String,
        // require: true
    }

});

module.exports = mongoose.model('Customer', customerSchema);
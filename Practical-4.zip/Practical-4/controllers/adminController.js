const User = require('../models/userModel');
const bcrypt = require('bcrypt');

//<<<----- For Get Admin Dashboard Page----->>>
const getAdminDashboard = async (req, res) => {
    try {

        res.render('adminDashboard', { title: "Dashboard" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get User Add Page----->>>
const getUserAddPage = async (req, res) => {
    try {

        res.render('addUser', { title: "Add New User" })

    } catch (error) {

        console.log(error.message);

    }
};
//<<<----- For Password Bcrypt ----->>>
const securePassword = async (password) => {
    try {

        const passwordHash = await bcrypt.hash(password, 10);
        return passwordHash;

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Add New User ----->>>
const postUserAddPage = async (req, res) => {

    try {

        const password = req.body.password;
        const cpassword = req.body.cpassword;

        if (password === cpassword) {

            const spassword = await securePassword(req.body.password)

            const user = new User({
                username: req.body.username,
                email: req.body.email,
                mobileno: req.body.mobileno,
                birthDate : req.body.birthDate,
                city: req.body.city,
                password: spassword,
                usertype: req.body.roll

            });

            const userData = await user.save();

            if (userData) {

                res.redirect('/listUser');
            } else {
                res.render('addUser', { title: 'Add New User', message: 'User Adding has been failed..' });
            }

        } else {
            res.render('addUser', { title: 'Add New User', message: 'Password are not matching.' });
        }


    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get User List Page----->>>
const getlistUserPage = async (req, res) => {
    try {
      
       const Data =  await User.find()
            if (Data) {
                res.render("listUser", {
                    title : 'All Users',
                    list : Data
                });
            }
            else {
                console.log('Error in retrieving users list :' + err);
            }

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- Get User Edit Page ----->>>
const geteditUserPage = async (req, res) => {

    try {

        const id = req.params.id;

        const userData = await User.findById({ _id: id });

        if (userData) {

            res.render('editUser', { title: "Edit User", user: userData });

        } else {

            res.redirect('/error');
        }

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For User Details Update ----->>>
const postUpdateUser = async (req, res) => {

    try {

        const userData = await User.findByIdAndUpdate({ _id: req.body.user_id },
            {
                $set: {

                    username: req.body.username,
                    email: req.body.email,
                    mobileno: req.body.mobileno,
                    birthDate: req.body.birthDate,
                    city: req.body.city,
                }
            });
            res.redirect('/listUser')
    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Delete User----->>>
const getDeleteUser = async (req, res) => {
    try {
      
       const deleteRecord =  await User.findByIdAndRemove({_id :req.params.id})
       
            if (deleteRecord) {
                const Data =  await User.find()
                res.render("listUser", {
                    title : 'All Users',
                    list : Data
                })
            }
            else {
                console.log('Error in retrieving users list :' + err);
            }
    } catch (error) {

        console.log(error.message);

    }
};

module.exports = {
    getAdminDashboard,
    getUserAddPage,
    postUserAddPage,
    getlistUserPage,
    geteditUserPage,
    postUpdateUser,
    getDeleteUser
}
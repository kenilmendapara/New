const User = require('../models/userModel');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const config = require('../config/config');
const nodemailer = require('nodemailer');
const cookieParser = require('cookie-parser');

//<<<----- For Get Register Page----->>>
const getRegisterPage = async (req, res) => {
    try {

        res.render('register', { title: "Registration" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Password Bcrypt ----->>>
const securePassword = async (password) => {
    try {

        const passwordHash = await bcrypt.hash(password, 10);
        return passwordHash;

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Insert User ----->>>
const postInsertUser = async (req, res) => {

    try {

        const password = req.body.password;
        const cpassword = req.body.cpassword;

        if (password === cpassword) {

            const spassword = await securePassword(req.body.password)

            const user = new User({
                username: req.body.username,
                email: req.body.email,
                mobileno: req.body.mobileno,
                city: req.body.city,
                password: spassword,
                usertype: req.body.roll

            });

            const token = await user.generateAuthToken();

            const userData = await user.save();

            if (userData) {
                sendVerifyMail(req.body.username, req.body.email, userData._id);

                res.redirect('/login');
            } else {
                res.render('register', { title: 'Registration', message: 'Your Registration has been failed..' });
            }

        } else {
            res.render('register', { title: 'Registration', message: 'Password are not matching.' });
        }


    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For New User Mail Varification ----->>>
const sendVerifyMail = async (username, email) => {
    try {

        const transpoter = nodemailer.createTransport({
            host: 'smtp.gmail.com',
            port: 587,
            secure: false,
            requireTLS: true,
            auth: {
                user: config.emailUser,
                pass: config.emailPassword
            }
        });


        const mailOptions = {

            from: config.emailUser,
            to: email,
            subject: 'For Varification E-mail',
            html: `<p>Hii ${username}, You have been completed registration successfully.</p>`
        }
        transpoter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.log(error);
            } else {
                console.log("Email has been sent :- ", info.response);
            }

        });

    } catch (error) {

        console.log(error.message);

    }

};

//<<<----- For Get Login Page----->>>
const getLoginPage = async (req, res) => {
    try {

        res.render('login', { title: "Login" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Verify Login User ----->>>
const postVerifyLogin = async (req, res) => {

    try {

        const email = req.body.email;
        const password = req.body.password;
        const userData = await User.findOne({ email: email });

        if (userData) {

            const passwordMatch = await bcrypt.compare(password, userData.password);
            
            const token = await userData.generateAuthToken();
        

            if (passwordMatch) {
                if (userData.roll === 0) {

                    res.redirect('/userDashboard');

                } else {

                    res.redirect('/adminDashboard');

                }

            } else {
                res.render('login', { title: 'Login', message: 'Your Details Is Incorrect' });
            }

        }
        else {
            res.render('login', { title: 'Login', message: ' Your Details Is Incorrect' });
        }

    } catch (error) {

        console.log(error.message);

    }

};


//<<<----- For Get 404 Page----->>>
const getError404Page = async (req, res) => {
    try {

        res.render('404-error', { title: "404 error" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get User Dashboard Page----->>>
const getUserDashboard = async (req, res) => {
    try {

        res.render('userDashboard', { title: "Dashboard" })

    } catch (error) {

        console.log(error.message);

    }
};
module.exports = {
    getLoginPage,
    getRegisterPage,
    postInsertUser,
    getError404Page,
    postVerifyLogin,
    getUserDashboard
}
const Service = require('../models/servicemodel');

//<<<----- For Service Add Page----->>>
const getAddServicePage = async (req, res) => {
    try {

        res.render('addService', { title: "Add New Service" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Insert New Service ----->>>
const postAddServicePage = async (req, res) => {

    try {

        const service = new Service({
            vehicleNumber: req.body.vehicleNumber,
            email: req.body.email,
            pickUpDate: req.body.pickUpDate,
            dropDate: req.body.dropDate,
            location: req.body.location

        });

        const serviceData = await service.save();

        if (serviceData) {
            res.render('listService', { title: 'Services', message: 'Your Data Add SuccesFully..' });
        } else {
            res.render('listService', { title: 'Services', message: 'Your Data Add Failed' });
        }

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get Service List Page----->>>
const getlistServicePage = async (req, res) => {
    try {
        const Data = await Service.find()
            if (Data) {
                res.render("listService", {
                    title : 'All Services',
                    list : Data
                });
            }
            else {
                console.log('Error in retrieving services list :' + err);
            }

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- Get Service Edit Page ----->>>
const geteditServicePage = async (req, res) => {

    try {

        const id = req.params.id;

        const serviceData = await Service.findById({ _id: id });

        if (serviceData) {

            res.render('editService', { title: "Edit Service", service: serviceData });

        } else {

            res.redirect('/error');
        }

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Service Details Update ----->>>
const postUpdateService = async (req, res) => {

    try {

        const serviceData = await Service.findByIdAndUpdate({ _id: req.body.service_id },
            {
                $set: {
                    vehicleNumber: req.body.vehicleNumber,
                    email: req.body.email,
                    pickUpDate: req.body.pickUpDate,
                    dropDate: req.body.dropDate,
                    location: req.body.location
                }
            });
            
            res.redirect('/listService')
    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Delete Sevice----->>>
const getDeleteService = async (req, res) => {
    try {
      
       const deleteRecord =  await Service.findByIdAndRemove({_id :req.params.id})
       
            if (deleteRecord) {
                const Data =  await Service.find()
                res.render("listService", {
                    title : 'All Services',
                    list : Data
                })
            }
            else {
                console.log('Error in retrieving services list :' + err);
            }
    } catch (error) {

        console.log(error.message);

    }
};


module.exports = {
    getAddServicePage,
    postAddServicePage,
    getlistServicePage,
    geteditServicePage,
    postUpdateService,
    getDeleteService
}

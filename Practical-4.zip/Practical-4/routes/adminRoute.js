const express = require('express');
const ejs = require('ejs');
const path = require('path');
const bodyParser = require('body-parser');
const route = express();

const adminController = require('../controllers/adminController');

const static_path = path.join(__dirname, "../public/");
route.use(express.static(static_path));

route.use(bodyParser.json());
route.use(bodyParser.urlencoded({ extended: true }));

route.set('view engine', 'ejs');
route.set('views', './views/admin');


route.get("/adminDashboard", adminController.getAdminDashboard);

route.get("/addUser", adminController.getUserAddPage);

route.post("/addUser", adminController.postUserAddPage);

route.get("/listUser", adminController.getlistUserPage);

route.get("/editUser/:id", adminController.geteditUserPage);

route.post("/editUser/:id", adminController.postUpdateUser);

route.get("/deleteUser/:id", adminController.getDeleteUser);



module.exports = route;
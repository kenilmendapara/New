const express = require('express');
const ejs = require('ejs');
const path = require('path');
const bodyParser = require('body-parser');
const route = express();

const customerController = require('../controllers/customerController');

const static_path = path.join(__dirname, "../public/");
route.use(express.static(static_path));

route.use(bodyParser.json());
route.use(bodyParser.urlencoded({ extended: true }));

route.set('view engine', 'ejs');
route.set('views', './views/customer');

route.get("/addCustomer", customerController.getAddCustomerPage);

route.post("/addCustomer", customerController.postAddCustomerPage);

route.get("/listCustomer", customerController.getlistCustomerPage);

route.get("/editCustomer/:id", customerController.geteditCustomerPage);

route.post("/editCustomer/:id", customerController.geteditCustomerPage);

route.get("/deleteCustomer/:id", customerController.getDeleteCustomer);

module.exports = route;

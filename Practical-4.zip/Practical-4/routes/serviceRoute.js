const express = require('express');
const ejs = require('ejs');
const path = require('path');
const bodyParser = require('body-parser');
const route = express();

const serviceController = require('../controllers/serviceController');

const static_path = path.join(__dirname, "../public/");
route.use(express.static(static_path));

route.use(bodyParser.json());
route.use(bodyParser.urlencoded({ extended: true }));

route.set('view engine', 'ejs');
route.set('views', './views/service');

route.get("/addService", serviceController.getAddServicePage);

route.post("/addService", serviceController.postAddServicePage);

route.get("/listService", serviceController.getlistServicePage);

route.get("/editService/:id", serviceController.geteditServicePage);

route.post("/editService/:id", serviceController.postUpdateService);

route.get("/deleteService/:id", serviceController.getDeleteService);






module.exports = route;
const express = require('express');
const ejs = require('ejs');
const path = require('path');
const bodyParser = require('body-parser');
const route = express();
const cookieParser = require('cookie-parser');

const userController = require('../controllers/userController');

const static_path = path.join(__dirname, "../public/");
route.use(express.static(static_path));
route.use(cookieParser());

route.use(bodyParser.json());
route.use(bodyParser.urlencoded({ extended: true }));

route.set('view engine', 'ejs');
route.set('views', './views');

route.get("/login", userController.getLoginPage);

route.post("/login", userController.postVerifyLogin);

route.get("/register", userController.getRegisterPage);

route.post('/register', userController.postInsertUser);

route.get("/error", userController.getError404Page);

route.get("/userDashboard", userController.getUserDashboard);


module.exports = route;
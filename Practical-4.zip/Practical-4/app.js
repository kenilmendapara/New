const express = require('express');
const app = express();
const port = process.env.PORT || 3232;

const mongoose = require('mongoose');
mongoose.connect("mongodb://0.0.0.0:27017/Practical-4", {
    useNewUrlParser: true
});

const userRoute = require('./routes/userRoute')
app.use('/', userRoute);

const serviceRoute = require('./routes/serviceRoute')
app.use('/', serviceRoute);

const customerRoute = require('./routes/customerRoute')
app.use('/', customerRoute);

const adminRoute = require('./routes/adminRoute')
app.use('/', adminRoute);

app.listen(port, () => {
    console.log(`server is listening on http://localhost:${port}/login`);
});